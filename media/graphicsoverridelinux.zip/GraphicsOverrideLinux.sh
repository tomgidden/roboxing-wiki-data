java/bin/java -DlibertySystems.configFile=AutoMaker.configFile.xml -Dprism.verbose=true -Dprism.forceGPU=true -jar AutoMaker.jar
